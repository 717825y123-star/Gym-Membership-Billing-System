package main;

import exception.GymException;
import model.AttendanceRecord;
import model.Invoice;
import model.Member;
import model.Payment;
import model.Plan;
import model.Subscription;
import model.Trainer;
import service.GymService;
import util.InputUtil;

public class Main {
public static void main(String[] args) {
GymService service = new GymService();
int choice;

do {
System.out.println("\n========== GYM MEMBERSHIP SYSTEM ==========");
System.out.println("1. Add Member");
System.out.println("2. Add Plan");
System.out.println("3. Start or Renew Subscription");
System.out.println("4. Record Attendance");
System.out.println("5. Generate Invoice");
System.out.println("6. Record Payment");
System.out.println("7. Display Members");
System.out.println("8. Display Plans");
System.out.println("9. Display Invoices");
System.out.println("10. Attendance Summary");
System.out.println("11. Add Trainer");
System.out.println("12. Display Trainers");
System.out.println("13. Display Payments");
System.out.println("14. Simulate Subscription Expiry");
System.out.println("0. Exit");

choice = InputUtil.readInt("Enter your choice: ");

try {
switch (choice) {
case 1:
String name = InputUtil.readString("Enter member name: ");
String phone = InputUtil.readString("Enter phone number: ");
String email = InputUtil.readString("Enter email: ");

Member member = service.addMember(name, phone, email);

System.out.println("Member added successfully.");
System.out.println(member);
break;

case 2:
String planName = InputUtil.readString("Enter plan name: ");
int duration = InputUtil.readInt("Enter duration in months: ");
double price = InputUtil.readDouble("Enter plan price: ");
double tax = InputUtil.readDouble("Enter tax percentage: ");
double penalty = InputUtil.readDouble("Enter late renewal penalty: ");

Plan plan = service.addPlan(planName, duration, price, tax, penalty);

System.out.println("Plan added successfully.");
System.out.println(plan);
break;

case 3:
service.displayMembers();
service.displayPlans();

int memberId = InputUtil.readInt("Enter member ID: ");
int planId = InputUtil.readInt("Enter plan ID: ");

Subscription subscription = service.startOrRenewSubscription(memberId, planId);
System.out.println(subscription);
break;

case 4:
int attendanceMemberId = InputUtil.readInt("Enter member ID: ");

AttendanceRecord attendance = service.recordAttendance(attendanceMemberId);

System.out.println("Attendance recorded successfully.");
System.out.println(attendance);
break;

case 5:
service.displayMembers();

int invoiceMemberId = InputUtil.readInt("Enter member ID: ");

Invoice invoice = service.generateInvoice(invoiceMemberId);

invoice.display();
break;

case 6:
service.displayInvoices();

int invoiceId = InputUtil.readInt("Enter invoice ID: ");
double amount = InputUtil.readDouble("Enter payment amount: ");
String paymentMode = InputUtil.readString("Enter payment mode: ");

Payment payment = service.recordPayment(invoiceId, amount, paymentMode);

System.out.println("Payment recorded successfully.");
System.out.println(payment);
payment.getInvoice().display();
break;

case 7:
service.displayMembers();
break;

case 8:
service.displayPlans();
break;

case 9:
service.displayInvoices();
break;

case 10:
int summaryMemberId = InputUtil.readInt("Enter member ID: ");
service.displayAttendance(summaryMemberId);
break;

case 11:
String trainerName = InputUtil.readString("Enter trainer name: ");
String specialization = InputUtil.readString("Enter specialization: ");

Trainer trainer = service.addTrainer(trainerName, specialization);

System.out.println("Trainer added successfully.");
System.out.println(trainer);
break;

case 12:
service.displayTrainers();
break;

case 13:
service.displayPayments();
break;

case 14:
int expiryMemberId = InputUtil.readInt("Enter member ID: ");
service.expireSubscriptionForDemo(expiryMemberId);
break;

case 0:
System.out.println("Exiting Gym Membership System.");
break;

default:
System.out.println("Invalid choice. Please try again.");
}
} catch (GymException e) {
System.out.println("Error: " + e.getMessage());
}

} while (choice != 0);

InputUtil.sc.close();
}
}