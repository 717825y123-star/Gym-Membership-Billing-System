package model;

import java.time.LocalDate;
import java.time.LocalTime;

public class AttendanceRecord {
private Member member;
private LocalDate attendanceDate;
private LocalTime attendanceTime;

public AttendanceRecord(Member member, LocalDate attendanceDate, LocalTime attendanceTime) {
this.member = member;
this.attendanceDate = attendanceDate;
this.attendanceTime = attendanceTime;
}

public Member getMember() {
return member;
}

public LocalDate getAttendanceDate() {
return attendanceDate;
}

public LocalTime getAttendanceTime() {
return attendanceTime;
}

public String toString() {
return "Member: " + member.getName() + " | Date: " + attendanceDate + " | Time: " + attendanceTime;
}
}