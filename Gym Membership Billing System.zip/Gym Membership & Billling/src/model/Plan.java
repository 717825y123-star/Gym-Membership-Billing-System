package model;

public class Plan {
private int planId;
private String planName;
private int durationMonths;
private double price;
private double taxRate;
private double latePenalty;

public Plan(int planId, String planName, int durationMonths, double price, double taxRate, double latePenalty) {
this.planId = planId;
this.planName = planName;
this.durationMonths = durationMonths;
this.price = price;
this.taxRate = taxRate;
this.latePenalty = latePenalty;
}

public int getPlanId() {
return planId;
}

public String getPlanName() {
return planName;
}

public int getDurationMonths() {
return durationMonths;
}

public double getPrice() {
return price;
}

public double getTaxRate() {
return taxRate;
}

public double getLatePenalty() {
return latePenalty;
}

public String toString() {
return "Plan ID: " + planId + " | Plan: " + planName + " | Duration: " + durationMonths + " months | Price: " + price + " | Tax: " + taxRate + "% | Late Penalty: " + latePenalty;
}
}