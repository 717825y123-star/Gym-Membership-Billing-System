package model;

import java.time.LocalDate;

public class Subscription {
private int subscriptionId;
private Member member;
private Plan plan;
private LocalDate startDate;
private LocalDate endDate;
private LocalDate previousEndDate;
private boolean active;
private double renewalPenalty;

public Subscription(int subscriptionId, Member member, Plan plan, LocalDate startDate, LocalDate endDate) {
this.subscriptionId = subscriptionId;
this.member = member;
this.plan = plan;
this.startDate = startDate;
this.endDate = endDate;
this.previousEndDate = null;
this.active = true;
this.renewalPenalty = 0;
}

public int getSubscriptionId() {
return subscriptionId;
}

public Member getMember() {
return member;
}

public Plan getPlan() {
return plan;
}

public LocalDate getStartDate() {
return startDate;
}

public LocalDate getEndDate() {
return endDate;
}

public double getRenewalPenalty() {
return renewalPenalty;
}

public boolean isActive() {
return active && !LocalDate.now().isAfter(endDate);
}

public boolean isExpired() {
return LocalDate.now().isAfter(endDate);
}

public void renew(Plan plan, LocalDate newStartDate, LocalDate newEndDate, double penalty) {
this.previousEndDate = this.endDate;
this.plan = plan;
this.startDate = newStartDate;
this.endDate = newEndDate;
this.renewalPenalty = penalty;
this.active = true;
}

public void consumeRenewalPenalty() {
this.renewalPenalty = 0;
}

public void expireForDemo() {
this.endDate = LocalDate.now().minusDays(1);
this.active = false;
}

public String getStatus() {
return isActive() ? "ACTIVE" : "EXPIRED";
}

public String toString() {
return "Subscription ID: " + subscriptionId + " | Member: " + member.getName() + " | Plan: " + plan.getPlanName() + " | Start: " + startDate + " | End: " + endDate + " | Status: " + getStatus();
}
}