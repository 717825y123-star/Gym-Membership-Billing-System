package model;

import java.time.LocalDate;

public class Invoice {
private int invoiceId;
private Subscription subscription;
private LocalDate invoiceDate;
private LocalDate cycleStart;
private LocalDate cycleEnd;
private double subtotal;
private double tax;
private double penalty;
private double total;
private double paidAmount;

public Invoice(int invoiceId, Subscription subscription, LocalDate invoiceDate, LocalDate cycleStart, LocalDate cycleEnd, double penalty) {
this.invoiceId = invoiceId;
this.subscription = subscription;
this.invoiceDate = invoiceDate;
this.cycleStart = cycleStart;
this.cycleEnd = cycleEnd;
this.subtotal = subscription.getPlan().getPrice();
this.tax = subtotal * subscription.getPlan().getTaxRate() / 100.0;
this.penalty = penalty;
this.total = subtotal + tax + penalty;
this.paidAmount = 0;
}

public int getInvoiceId() {
return invoiceId;
}

public Subscription getSubscription() {
return subscription;
}

public double getTotal() {
return total;
}

public double getPaidAmount() {
return paidAmount;
}

public double getBalance() {
return total - paidAmount;
}

public boolean isPaid() {
return paidAmount >= total;
}

public void addPayment(double amount) {
paidAmount += amount;
}

public String getPaymentStatus() {
if (isPaid()) {
return "PAID";
}
if (paidAmount > 0) {
return "PARTIALLY PAID";
}
return "UNPAID";
}

public void display() {
System.out.println("\n========== INVOICE ==========");
System.out.println("Invoice ID: " + invoiceId);
System.out.println("Member: " + subscription.getMember().getName());
System.out.println("Plan: " + subscription.getPlan().getPlanName());
System.out.println("Invoice Date: " + invoiceDate);
System.out.println("Billing Cycle: " + cycleStart + " to " + cycleEnd);
System.out.printf("Subtotal: Rs. %.2f%n", subtotal);
System.out.printf("Tax: Rs. %.2f%n", tax);
System.out.printf("Penalty: Rs. %.2f%n", penalty);
System.out.printf("Total Amount: Rs. %.2f%n", total);
System.out.printf("Paid Amount: Rs. %.2f%n", paidAmount);
System.out.printf("Balance: Rs. %.2f%n", getBalance());
System.out.println("Payment Status: " + getPaymentStatus());
System.out.println("============================");
}
}