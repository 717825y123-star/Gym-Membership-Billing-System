package model;

import java.time.LocalDate;

public class Payment {
private int paymentId;
private Invoice invoice;
private double amount;
private LocalDate paymentDate;
private String paymentMode;

public Payment(int paymentId, Invoice invoice, double amount, LocalDate paymentDate, String paymentMode) {
this.paymentId = paymentId;
this.invoice = invoice;
this.amount = amount;
this.paymentDate = paymentDate;
this.paymentMode = paymentMode;
}

public int getPaymentId() {
return paymentId;
}

public Invoice getInvoice() {
return invoice;
}

public double getAmount() {
return amount;
}

public LocalDate getPaymentDate() {
return paymentDate;
}

public String getPaymentMode() {
return paymentMode;
}

public String toString() {
return "Payment ID: " + paymentId + " | Invoice ID: " + invoice.getInvoiceId() + " | Amount: Rs. " + amount + " | Date: " + paymentDate + " | Mode: " + paymentMode;
}
}