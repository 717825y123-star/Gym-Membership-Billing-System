package model;

public class Trainer {
private int trainerId;
private String name;
private String specialization;

public Trainer(int trainerId, String name, String specialization) {
this.trainerId = trainerId;
this.name = name;
this.specialization = specialization;
}

public int getTrainerId() {
return trainerId;
}

public String getName() {
return name;
}

public String getSpecialization() {
return specialization;
}

public String toString() {
return "Trainer ID: " + trainerId + " | Name: " + name + " | Specialization: " + specialization;
}
}