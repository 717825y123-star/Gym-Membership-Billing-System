package model;


public class Member {
private int memberId;
private String name;
private String phone;
private String email;

public Member(int memberId, String name, String phone, String email) {
this.memberId = memberId;
this.name = name;
this.phone = phone;
this.email = email;
}

public int getMemberId() {
return memberId;
}

public String getName() {
return name;
}

public String getPhone() {
return phone;
}

public String getEmail() {
return email;
}

public String toString() {
return "Member ID: " + memberId + " | Name: " + name + " | Phone: " + phone + " | Email: " + email;
}
}