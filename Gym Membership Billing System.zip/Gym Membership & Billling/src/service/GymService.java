package service;

import model.*;
import exception.GymException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class GymService {
private ArrayList<Member> members = new ArrayList<>();
private ArrayList<Plan> plans = new ArrayList<>();
private ArrayList<Trainer> trainers = new ArrayList<>();
private ArrayList<Subscription> subscriptions = new ArrayList<>();
private ArrayList<AttendanceRecord> attendanceRecords = new ArrayList<>();
private ArrayList<Invoice> invoices = new ArrayList<>();
private ArrayList<Payment> payments = new ArrayList<>();

private int memberCounter = 1;
private int planCounter = 1;
private int trainerCounter = 1;
private int subscriptionCounter = 1;
private int invoiceCounter = 1;
private int paymentCounter = 1;

public Member addMember(String name, String phone, String email) {
Member member = new Member(memberCounter++, name, phone, email);
members.add(member);
return member;
}

public Plan addPlan(String name, int duration, double price, double tax, double penalty) throws GymException {
if (duration <= 0 || price <= 0 || tax < 0 || penalty < 0) {
throw new GymException("Invalid plan details.");
}
Plan plan = new Plan(planCounter++, name, duration, price, tax, penalty);
plans.add(plan);
return plan;
}

public Trainer addTrainer(String name, String specialization) {
Trainer trainer = new Trainer(trainerCounter++, name, specialization);
trainers.add(trainer);
return trainer;
}

public Member findMember(int memberId) throws GymException {
for (Member member : members) {
if (member.getMemberId() == memberId) {
return member;
}
}
throw new GymException("Member not found.");
}

public Plan findPlan(int planId) throws GymException {
for (Plan plan : plans) {
if (plan.getPlanId() == planId) {
return plan;
}
}
throw new GymException("Plan not found.");
}

public Subscription findSubscription(int memberId) {
for (Subscription subscription : subscriptions) {
if (subscription.getMember().getMemberId() == memberId) {
return subscription;
}
}
return null;
}

public Invoice findInvoice(int invoiceId) throws GymException {
for (Invoice invoice : invoices) {
if (invoice.getInvoiceId() == invoiceId) {
return invoice;
}
}
throw new GymException("Invoice not found.");
}

public Subscription startOrRenewSubscription(int memberId, int planId) throws GymException {
Member member = findMember(memberId);
Plan plan = findPlan(planId);
Subscription existing = findSubscription(memberId);

LocalDate today = LocalDate.now();
LocalDate startDate = today;
double penalty = 0;

if (existing != null && existing.isActive()) {
throw new GymException("Member already has an active subscription.");
}

if (existing != null && existing.isExpired()) {
penalty = plan.getLatePenalty();
}

LocalDate endDate = startDate.plusMonths(plan.getDurationMonths());

Subscription subscription;

if (existing != null) {
existing.renew(plan, startDate, endDate, penalty);
subscription = existing;
} else {
subscription = new Subscription(subscriptionCounter++, member, plan, startDate, endDate);
subscriptions.add(subscription);
}

System.out.println("\nSubscription updated successfully.");
System.out.println(subscription);

if (penalty > 0) {
System.out.printf("Late renewal penalty applicable: Rs. %.2f%n", penalty);
}

return subscription;
}
public AttendanceRecord recordAttendance(int memberId) throws GymException {
Member member = findMember(memberId);
Subscription subscription = findSubscription(memberId);

if (subscription == null || !subscription.isActive()) {
throw new GymException("Attendance denied. Member must have an active subscription.");
}

AttendanceRecord record = new AttendanceRecord(member, LocalDate.now(), LocalTime.now());
attendanceRecords.add(record);

return record;
}

public Invoice generateInvoice(int memberId) throws GymException {
Subscription subscription = findSubscription(memberId);

if (subscription == null) {
throw new GymException("No subscription found for this member.");
}

if (!subscription.isActive()) {
throw new GymException("Subscription is expired. Renew it before generating an invoice.");
}

double penalty = subscription.getRenewalPenalty();

Invoice invoice = new Invoice(invoiceCounter++, subscription, LocalDate.now(), subscription.getStartDate(), subscription.getEndDate(), penalty);

invoices.add(invoice);
subscription.consumeRenewalPenalty();

return invoice;
}
public void expireSubscriptionForDemo(int memberId) throws GymException {
Subscription subscription = findSubscription(memberId);

if (subscription == null) {
throw new GymException("No subscription found.");
}

subscription.expireForDemo();

System.out.println("Subscription expired for demonstration.");
System.out.println(subscription);
}

public Payment recordPayment(int invoiceId, double amount, String paymentMode) throws GymException {
Invoice invoice = findInvoice(invoiceId);

if (amount <= 0) {
throw new GymException("Payment amount must be greater than zero.");
}

if (amount > invoice.getBalance()) {
throw new GymException("Payment amount exceeds the invoice balance.");
}

if (invoice.getBalance() <= 0) {
throw new GymException("Invoice is already fully paid.");
}

Payment payment = new Payment(paymentCounter++, invoice, amount, LocalDate.now(), paymentMode);

invoice.addPayment(amount);
payments.add(payment);

return payment;
}

public void displayMembers() {
if (members.isEmpty()) {
System.out.println("No members available.");
return;
}

for (Member member : members) {
System.out.println("\n" + member);
Subscription subscription = findSubscription(member.getMemberId());

if (subscription != null) {
System.out.println(subscription);
} else {
System.out.println("Subscription: NOT STARTED");
}
}
}

public void displayPlans() {
if (plans.isEmpty()) {
System.out.println("No plans available.");
return;
}

for (Plan plan : plans) {
System.out.println(plan);
}
}

public void displayTrainers() {
if (trainers.isEmpty()) {
System.out.println("No trainers available.");
return;
}

for (Trainer trainer : trainers) {
System.out.println(trainer);
}
}

public void displayInvoices() {
if (invoices.isEmpty()) {
System.out.println("No invoices available.");
return;
}

for (Invoice invoice : invoices) {
invoice.display();
}
}

public void displayAttendance(int memberId) throws GymException {
Member member = findMember(memberId);
int count = 0;

System.out.println("\nAttendance Summary for " + member.getName());

for (AttendanceRecord record : attendanceRecords) {
if (record.getMember().getMemberId() == memberId) {
System.out.println(record);
count++;
}
}

System.out.println("Total Attendance: " + count);
}

public void displayPayments() {
if (payments.isEmpty()) {
System.out.println("No payments available.");
return;
}

for (Payment payment : payments) {
System.out.println(payment);
}
}
}